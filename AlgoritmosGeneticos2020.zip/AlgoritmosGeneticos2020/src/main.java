
import binario.GeneticoV1;
import extras.GeneradorInstancias;
import tsp.Individuo;
import tsp.geneticoV2;
import tsp.cruza; 

public class main{

  public static void main(String[] args) {
//    try {
//     Individuo.matrizDistancias = GeneradorInstancias.cargarMatriz();
//           System.out.println();
//      Individuo i = new Individuo(new int[]{997,5,17,18});
//      //Individuo i = new Individuo(3,500);
//      i.Asexual(997,1000);
//      System.out.println(i.getFitness());
//    } catch (Exception e) {
//      // TODO Auto-generated catch block
//      e.printStackTrace(); 
//    }
//    
//    
//    System.out.println("\n \n \n");
//   geneticoV2 gen = new geneticoV2(50000,0.3,20,997,1000);
//       gen.evolucionar();
        
   
    }
}













