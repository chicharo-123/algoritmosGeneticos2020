/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TresSat;

import java.util.ArrayList;
/**
 *
 * @author chicharo
*/
public class Clausula {
           
    private int a;
    private int b;
    private int c;

    public Clausula(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    public void setA(int a) {
        this.a = a;
    }
    public void setB(int b) {
        this.b = b;
    }
    public void setC(int c) {
        this.c = c;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public int getC() {
        return c;
    }
    
}
